package cordova.plugin.backgroundrunningservice;


import org.apache.cordova.*;
import org.json.JSONArray;
import org.json.JSONException;
import android.widget.Toast;
import android.content.Context;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.app.ActivityManager;
import android.support.v4.app.NotificationCompat;

/**
 * This class echoes a string called from JavaScript.
 */
public class BackgroundRunningService extends CordovaPlugin {
    Intent mServiceIntent;
    private WakeUpService mService;
    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if (action.equals("runBackground")) {
            Context context = cordova.getActivity().getApplicationContext();
            mService = new WakeUpService();
            mServiceIntent = new Intent(this, mService.getClass());
            if (!isServiceRunning(mService.getClass())) {
                 context.startService(mServiceIntent);
            }
            return true;
        } else {
            return false;
        }
    }
    
    private boolean isServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i ("Service status", "Running");
                return true;
            }
        }
        Log.i ("Service status", "Not running");
        return false;
    }

    @Override
    protected void onDestroy() {
        Context context = cordova.getActivity().getApplicationContext();

        context.stopService(mServiceIntent);
        super.onDestroy();
    }
}
