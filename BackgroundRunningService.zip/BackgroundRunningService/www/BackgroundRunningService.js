var exec = require("cordova/exec");

exports.runBackground = function(successCallback, errorCallback) {
  cordova.exec(
    successCallback,
    errorCallback,
    "BackgroundRunningService",
    "runBackground",
    []
  );
};
